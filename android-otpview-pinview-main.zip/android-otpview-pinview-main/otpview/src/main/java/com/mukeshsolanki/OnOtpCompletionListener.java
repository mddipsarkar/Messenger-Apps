package com.mukeshsolanki;

public interface OnOtpCompletionListener {
  void onOtpCompleted(String otp);
}